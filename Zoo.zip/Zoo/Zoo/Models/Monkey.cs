﻿using System;
using Zoo.Interfaces;

namespace Zoo.Models
{
    public class Monkey : IAnimal
    {
        public string Name { get; set; }
        public void MakeSound()
        {
            Console.WriteLine("Any sound by monkey");
        }
    }
}
