﻿using System;
using Zoo.Strategy;

namespace Zoo.Models
{
    public class Animal
    {
        public string Name { get; set; }
        public IFeedigStrategy Feedig { get; set; }

        public void FeedAnimal()
        {
            Console.WriteLine($"{Name} is being fed");
            Feedig.Feed();
        }
    }
}
