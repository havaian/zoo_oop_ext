﻿using System;
using Zoo.Interfaces;

namespace Zoo.Models
{
    public class Lion : IAnimal
    {
        public string Name { get; set; }
        public void MakeSound()
        {
            Console.WriteLine("Roar");
        }
    }
}
