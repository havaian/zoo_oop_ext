﻿using System;
using System.Web;

namespace Zoo.Models
{
    public abstract class Sample
    {
        public Sample(string name) 
        {
            Name = name;
        }
        public int Id { get; set; }

        public string Name { get; set; }

        public bool IsDeleted { get; set; }

        public void A(string name)
        {
            Console.WriteLine("-----------");
        }
    }
}
