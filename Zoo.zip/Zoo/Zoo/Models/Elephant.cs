﻿using System;
using Zoo.Interfaces;

namespace Zoo.Models
{
    public class Elephant : IAnimal
    {
        public string Name { get; set; }
        public void MakeSound()
        {
            Console.WriteLine("Any sound");
        }
    }
}
