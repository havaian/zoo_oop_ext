﻿namespace Zoo.Strategy
{
    public interface IFeedigStrategy
    {
        void Feed();
    }
}
