﻿using System;

namespace Zoo.Strategy
{
    public class HerbivoreFeedingStrategy : IFeedigStrategy
    {
        public void Feed()
        {
            Console.WriteLine("Feeding with vegitables");
        }




    }
}
