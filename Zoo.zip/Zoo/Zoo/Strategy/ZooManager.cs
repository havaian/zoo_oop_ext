﻿using System;
using System.Web;

namespace Zoo.Strategy
{
    public class ZooManager
    {
        private static ZooManager instance;

        private ZooManager() { }

        public static ZooManager GetInstance()
        {
            if (instance == null)
            {
                instance = new ZooManager();
            }
            return instance;
        }

        public void PerformTask(string task)
        {
            Console.WriteLine($"Zoo manager perform task: {task}");
        }
    }
}
