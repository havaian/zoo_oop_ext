﻿using System;

namespace Zoo.Strategy
{
    public class CarnivoreFeedingStrategy : IFeedigStrategy
    {
        public void Feed()
        {
            Console.WriteLine("Feeding with meat");
        }
    }
}
