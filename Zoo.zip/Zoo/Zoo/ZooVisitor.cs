﻿using System;
using Zoo.Interfaces;
using Zoo.Models;

namespace Zoo.Service
{
    public class ZooVisitor : IZooObserver
    {
        public string Name { get; set; }
        public void Update(string action, Animal animal)
        {
            Console.WriteLine($"{Name}");
        }
    }
}
