﻿using Zoo.Models;

namespace Zoo.Interfaces
{
    public interface IZooObserver
    {
        void Update(string action, Animal animal);
    }
}
