﻿namespace Zoo.Interfaces
{
    public interface IAnimalFactory
    {
        IAnimal AddAnimal(string name);
    }
}
