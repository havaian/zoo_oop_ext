﻿namespace Zoo.Interfaces
{
    public interface IAnimal
    {
        void MakeSound();
    }
}
