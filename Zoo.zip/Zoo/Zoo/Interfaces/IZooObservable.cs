﻿using Zoo.Models;
using Zoo.Service;

namespace Zoo.Interfaces
{
    public interface IZooObservable
    {
        void AddObserver(ZooVisitor zooObserver);

        void RemoveObserver(ZooVisitor zooObserver);

        void NotifyObserver(Animal animal);
    }
}
