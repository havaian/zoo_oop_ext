﻿using Zoo.Interfaces;
using Zoo.Models;

namespace Zoo.Factory
{
    public class ElephantFactory : IAnimalFactory
    {
        public IAnimal AddAnimal(string name)
        {
            return new Elephant { Name = name };
        }
    }
}
