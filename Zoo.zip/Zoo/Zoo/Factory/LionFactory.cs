﻿using Zoo.Interfaces;
using Zoo.Models;

namespace Zoo.Factory
{
    public class LionFactory : IAnimalFactory
    {
        public IAnimal AddAnimal(string name)
        {
            return new Lion { Name = name };
        }
    }
}
