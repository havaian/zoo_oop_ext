﻿using Zoo.Interfaces;
using Zoo.Models;

namespace Zoo.Factory
{
    public class MonkeyFactory : IAnimalFactory
    {
        public IAnimal AddAnimal(string name)
        {
            return new Monkey { Name = name };
        }
    }
}
