﻿using System;
using Zoo.Factory;
using Zoo.Models;
using Zoo.Service;
using Zoo.Strategy;

namespace Zoo
{
    class Program
    {
        static void Main(string[] args)
        {


            var herbivoreFeed = new HerbivoreFeedingStrategy();
            var carnivoreFeed = new CarnivoreFeedingStrategy();

            var monkey = new Animal { Name = "Monkey", Feedig = herbivoreFeed };
            var lion = new Animal { Name = "Lion", Feedig= carnivoreFeed };

            monkey.FeedAnimal();
            lion.FeedAnimal();

            var zooManager = ZooManager.GetInstance();
            zooManager.PerformTask("Action");

            Console.ReadLine();


            //var zoo = new Zu();

            //var visitor1 = new ZooVisitor { Name = "A" };
            //var visitor2 = new ZooVisitor { Name = "B"};
            //zoo.AddObserver(visitor1);
            //zoo.AddObserver(visitor2);

            //var lionFactory = new LionFactory();
            //var elephantFactory = new ElephantFactory();
            //var monkeyFactory = new MonkeyFactory();

            //var lion = lionFactory.AddAnimal("Simba");
            //var elephant = elephantFactory.AddAnimal("Dumbo");
            //var monkey = monkeyFactory.AddAnimal("Ehsken");

            //zoo.AddAnimal(lion);
            //zoo.AddAnimal(monkey);
            //zoo.AddAnimal(elephant);

            //zoo.DisplayAnimals();

            //var zooKeeper = new ZooKeeper();
            //zooKeeper.PerformTask(lion);
            //zooKeeper.PerformTask(monkey);
            //zooKeeper.PerformTask(elephant);
            //Console.ReadLine();

            var lion1 = new Lion();
        }
    }
}
