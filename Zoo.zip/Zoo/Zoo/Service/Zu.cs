﻿using System;
using System.Collections.Generic;
using Zoo.Interfaces;
using Zoo.Models;

namespace Zoo.Service
{
    public class Zu : IZooObservable
    {
        List<ZooVisitor> visitors = new List<ZooVisitor>();
        List<IAnimal> animals = new List<IAnimal>();
        int a = 1;

        public void AddAnimal(IAnimal animal)
        {
            animals.Add(animal);
        }

        public void RemoveAnimal(IAnimal animal) 
        {
            animals.Remove(animal);
        }

        public void DisplayAnimals()
        {
            foreach (var animal in animals)
            {
                Console.WriteLine($"Animal: {a++}");
            }
        }

        public void AddObserver(ZooVisitor zooObserver)
        {
            visitors.Add(zooObserver);
        }

        public void RemoveObserver(ZooVisitor zooObserver)
        {
           visitors.Remove(zooObserver);
        }

        public void NotifyObserver(Animal animal)
        {
            foreach (var visitor in visitors)
            {
                Console.WriteLine($"Animal: {animal.Name}");
            }
        }
    }
}
