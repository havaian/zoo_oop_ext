﻿using System;
using Zoo.Interfaces;

namespace Zoo
{
    public class ZooKeeper
    {
        public void PerformTask(IAnimal animal)
        {
            Console.WriteLine("Task:");
            animal.MakeSound();
        }
    }
}
